<%
	response.sendRedirect("welcome");
%>